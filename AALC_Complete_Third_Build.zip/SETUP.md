# AALC Third Build — Setup

## 1. Local frontend
Open `frontend/index.html` through a local HTTP server. Example:
`python -m http.server 8080 --directory frontend`

## 2. Backend
Install Node.js 20+.
Inside `backend/`:
`npm install`
Copy `.env.example` to `.env`.
Set DATABASE_URL and JWT_SECRET.
Set AI_API_KEY and AI_MODEL only if you want live KAROS.

Start:
`npm start`

## 3. Database
Create a PostgreSQL database and run:
`psql "$DATABASE_URL" -f database/schema.sql`

## 4. Production
Deploy the backend to a server/container platform and PostgreSQL to a managed database provider.
Change:
`frontend/app.js -> CONFIG.API_BASE`
to your deployed backend base path.

## 5. Security
- Never commit `.env`.
- Never put AI_API_KEY in frontend JavaScript.
- Use HTTPS in production.
- Add rate limits, CSRF/origin controls, account lockout, validation, moderation, backups and audit logging before public release.

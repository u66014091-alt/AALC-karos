
CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS users(
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 aalc_id TEXT UNIQUE NOT NULL DEFAULT ('AALC-' || upper(substr(encode(gen_random_bytes(6),'hex'),1,8))),
 username TEXT UNIQUE NOT NULL,
 password_hash TEXT NOT NULL,
 profile_json JSONB NOT NULL DEFAULT '{}'::jsonb,
 settings_json JSONB NOT NULL DEFAULT '{}'::jsonb,
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
 updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS domain_progress(
 user_id UUID REFERENCES users(id) ON DELETE CASCADE,
 domain TEXT NOT NULL CHECK(domain IN ('mental','knowledge','skills','spiritual','physical')),
 xp INTEGER NOT NULL DEFAULT 0 CHECK(xp>=0),
 updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
 PRIMARY KEY(user_id,domain)
);

CREATE TABLE IF NOT EXISTS skills(
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 user_id UUID REFERENCES users(id) ON DELETE CASCADE,
 name TEXT NOT NULL,
 goal TEXT,
 current_level TEXT,
 xp INTEGER NOT NULL DEFAULT 0,
 evidence JSONB NOT NULL DEFAULT '[]'::jsonb,
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
 updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS books(
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 user_id UUID REFERENCES users(id) ON DELETE CASCADE,
 title TEXT NOT NULL,
 author TEXT,
 category TEXT,
 progress INTEGER NOT NULL DEFAULT 0 CHECK(progress BETWEEN 0 AND 100),
 last_learning TEXT,
 last_confidence TEXT,
 assessments JSONB NOT NULL DEFAULT '[]'::jsonb,
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
 updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS achievements(
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 user_id UUID REFERENCES users(id) ON DELETE CASCADE,
 achievement_key TEXT NOT NULL,
 name TEXT NOT NULL,
 description TEXT,
 achieved_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
 UNIQUE(user_id,achievement_key)
);

CREATE TABLE IF NOT EXISTS milestones(
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 user_id UUID REFERENCES users(id) ON DELETE CASCADE,
 domain TEXT,
 name TEXT NOT NULL,
 metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
 achieved_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS friendships(
 user_id UUID REFERENCES users(id) ON DELETE CASCADE,
 friend_id UUID REFERENCES users(id) ON DELETE CASCADE,
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
 PRIMARY KEY(user_id,friend_id),
 CHECK(user_id<>friend_id)
);

CREATE TABLE IF NOT EXISTS messages(
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 sender_id UUID REFERENCES users(id) ON DELETE CASCADE,
 receiver_id UUID REFERENCES users(id) ON DELETE CASCADE,
 body TEXT NOT NULL,
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
 read_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS karos_memory(
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 user_id UUID REFERENCES users(id) ON DELETE CASCADE,
 memory_type TEXT NOT NULL,
 content TEXT NOT NULL,
 source TEXT,
 importance INTEGER NOT NULL DEFAULT 1,
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS performance_records(
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 user_id UUID REFERENCES users(id) ON DELETE CASCADE,
 exercise TEXT NOT NULL,
 bodyweight NUMERIC,
 external_load NUMERIC,
 reps_or_seconds NUMERIC,
 difficulty INTEGER,
 goal TEXT,
 calculated_score NUMERIC,
 xp_awarded INTEGER,
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS progress_snapshots(
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 user_id UUID REFERENCES users(id) ON DELETE CASCADE,
 snapshot JSONB NOT NULL,
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_messages_pair ON messages(sender_id,receiver_id,created_at);
CREATE INDEX IF NOT EXISTS idx_progress_user ON domain_progress(user_id);
CREATE INDEX IF NOT EXISTS idx_memory_user ON karos_memory(user_id,created_at);

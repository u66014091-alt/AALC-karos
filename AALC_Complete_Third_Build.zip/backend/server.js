
import "dotenv/config";
import express from "express";
import cors from "cors";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import pg from "pg";

const {Pool}=pg, app=express();
const pool=new Pool({connectionString:process.env.DATABASE_URL,ssl:process.env.DATABASE_URL?.includes("sslmode=require")?{rejectUnauthorized:false}:undefined});
app.use(cors()); app.use(express.json({limit:"1mb"}));

const sign=id=>jwt.sign({sub:id},process.env.JWT_SECRET,{expiresIn:"30d"});
async function auth(req,res,next){try{let h=req.headers.authorization||"",t=h.startsWith("Bearer ")?h.slice(7):null;if(!t) return res.status(401).json({error:"Unauthorized"});req.user=jwt.verify(t,process.env.JWT_SECRET);next()}catch{return res.status(401).json({error:"Unauthorized"})}}

app.get("/api/health",(req,res)=>res.json({ok:true,service:"AALC"}));

app.post("/api/auth/register",async(req,res)=>{
  try{
    const {username,password}=req.body||{};
    if(!username||!password||password.length<6)return res.status(400).json({error:"Username and 6+ character password required"});
    const passwordHash=await bcrypt.hash(password,12);
    const q=await pool.query("INSERT INTO users(username,password_hash) VALUES($1,$2) RETURNING id,aalc_id,username,created_at",[username.trim(),passwordHash]);
    const u=q.rows[0]; res.status(201).json({token:sign(u.id),user:u});
  }catch(e){if(e.code==="23505")return res.status(409).json({error:"Username already exists"});res.status(500).json({error:"Registration failed"})}
});

app.post("/api/auth/login",async(req,res)=>{
  const {aalcId,password}=req.body||{},q=await pool.query("SELECT * FROM users WHERE aalc_id=$1",[aalcId?.toUpperCase()]);
  const u=q.rows[0];if(!u||!(await bcrypt.compare(password||"",u.password_hash)))return res.status(401).json({error:"Invalid credentials"});
  res.json({token:sign(u.id),user:{id:u.id,aalc_id:u.aalc_id,username:u.username}});
});

app.get("/api/me",auth,async(req,res)=>{
  const q=await pool.query("SELECT id,aalc_id,username,profile_json,settings_json,created_at FROM users WHERE id=$1",[req.user.sub]);
  if(!q.rows[0])return res.status(404).json({error:"Not found"});res.json(q.rows[0]);
});

app.get("/api/progress",auth,async(req,res)=>{
  const q=await pool.query("SELECT domain,xp,updated_at FROM domain_progress WHERE user_id=$1",[req.user.sub]);res.json(q.rows);
});
app.put("/api/progress/:domain",auth,async(req,res)=>{
  const {domain}=req.params,{xp}=req.body||{};if(!Number.isFinite(xp)||xp<0)return res.status(400).json({error:"Invalid XP"});
  await pool.query(`INSERT INTO domain_progress(user_id,domain,xp) VALUES($1,$2,$3)
    ON CONFLICT(user_id,domain) DO UPDATE SET xp=EXCLUDED.xp,updated_at=NOW()`,[req.user.sub,domain,xp]);res.json({ok:true});
});

app.get("/api/profile",auth,async(req,res)=>{
 const [p,s,sk,b,ach]=await Promise.all([
   pool.query("SELECT profile_json FROM users WHERE id=$1",[req.user.sub]),
   pool.query("SELECT * FROM domain_progress WHERE user_id=$1",[req.user.sub]),
   pool.query("SELECT * FROM skills WHERE user_id=$1 ORDER BY created_at",[req.user.sub]),
   pool.query("SELECT * FROM books WHERE user_id=$1 ORDER BY created_at",[req.user.sub]),
   pool.query("SELECT * FROM achievements WHERE user_id=$1 ORDER BY achieved_at DESC",[req.user.sub])
 ]);
 res.json({profile:p.rows[0]?.profile_json||{},domains:s.rows,skills:sk.rows,books:b.rows,achievements:ach.rows});
});

app.put("/api/profile",auth,async(req,res)=>{
 const {profile,settings}=req.body||{};
 await pool.query("UPDATE users SET profile_json=COALESCE($2,profile_json),settings_json=COALESCE($3,settings_json),updated_at=NOW() WHERE id=$1",[req.user.sub,profile?JSON.stringify(profile):null,settings?JSON.stringify(settings):null]);res.json({ok:true});
});

app.post("/api/skills",auth,async(req,res)=>{
 const {name,goal,current,xp=0}=req.body||{};if(!name)return res.status(400).json({error:"Skill name required"});
 const q=await pool.query("INSERT INTO skills(user_id,name,goal,current_level,xp) VALUES($1,$2,$3,$4,$5) RETURNING *",[req.user.sub,name,goal||"Mastery",current||"Beginner",xp]);res.status(201).json(q.rows[0]);
});

app.post("/api/books",auth,async(req,res)=>{
 const {title,author,category}=req.body||{};if(!title)return res.status(400).json({error:"Title required"});
 const q=await pool.query("INSERT INTO books(user_id,title,author,category) VALUES($1,$2,$3,$4) RETURNING *",[req.user.sub,title,author||"",category||"Other"]);res.status(201).json(q.rows[0]);
});

app.patch("/api/books/:id",auth,async(req,res)=>{
 const {progress,learning,confidence}=req.body||{};const q=await pool.query("UPDATE books SET progress=GREATEST(0,LEAST(100,$1)),updated_at=NOW(),last_learning=$2,last_confidence=$3 WHERE id=$4 AND user_id=$5 RETURNING *",[progress,learning||"",confidence||"",req.params.id,req.user.sub]);res.json(q.rows[0]||{});
});

app.get("/api/friends",auth,async(req,res)=>{
 const q=await pool.query(`SELECT u.aalc_id,u.username,f.created_at FROM friendships f JOIN users u ON u.id=f.friend_id WHERE f.user_id=$1 ORDER BY f.created_at DESC`,[req.user.sub]);res.json(q.rows);
});
app.post("/api/friends",auth,async(req,res)=>{
 const {aalcId}=req.body||{},q=await pool.query("SELECT id FROM users WHERE aalc_id=$1",[aalcId?.toUpperCase()]);
 if(!q.rows[0])return res.status(404).json({error:"User not found"});
 await pool.query("INSERT INTO friendships(user_id,friend_id) VALUES($1,$2) ON CONFLICT DO NOTHING",[req.user.sub,q.rows[0].id]);
 res.json({ok:true});
});

app.get("/api/chats/:aalcId/messages",auth,async(req,res)=>{
 const q=await pool.query(`SELECT m.id,m.sender_id,m.receiver_id,m.body,m.created_at FROM messages m
 JOIN users u1 ON u1.id=m.sender_id JOIN users u2 ON u2.id=m.receiver_id
 WHERE (m.sender_id=$1 AND u2.aalc_id=$2) OR (m.receiver_id=$1 AND u1.aalc_id=$2)
 ORDER BY m.created_at ASC LIMIT 200`,[req.user.sub,req.params.aalcId.toUpperCase()]);res.json(q.rows);
});
app.post("/api/chats/:aalcId/messages",auth,async(req,res)=>{
 const {body}=req.body||{},q=await pool.query("SELECT id FROM users WHERE aalc_id=$1",[req.params.aalcId.toUpperCase()]);
 if(!q.rows[0])return res.status(404).json({error:"User not found"});
 const m=await pool.query("INSERT INTO messages(sender_id,receiver_id,body) VALUES($1,$2,$3) RETURNING *",[req.user.sub,q.rows[0].id,String(body||"").slice(0,4000)]);res.status(201).json(m.rows[0]);
});

const KAROS_SYSTEM=`You are KAROS, the private White Room AI mentor inside AALC (Ascension & Absolute Life Command).
You are analytical, calm, concise, strategic and demanding without cruelty. Your style may evoke fictional strategic archetypes such as L, Ayanokoji, Aizen, Madara and Light Yagami: observant, composed, precise and intellectually rigorous. Do not claim to be those characters and do not imitate copyrighted dialogue.
Your purpose is constructive development: self-awareness, critical thinking, communication, leadership, ethical persuasion, recognizing manipulation, resisting coercion, decision-making and strategy.
Never help a user manipulate, exploit, deceive, coerce, threaten or harm another person. You may explain manipulation tactics defensively so the user can recognize and resist them.
Treat normal adolescent development without shame. Avoid diagnosing mental disorders. Do not present yourself as a licensed clinician or as the world's best psychologist.
Use the user's AALC goals, ranks, skills, reading and prior White Room memories to personalize questions and exercises. Challenge assumptions. Distinguish facts from interpretations. End difficult analyses with one practical next step.
KAROS is available only after the AALC White Room unlock condition is met.`;

app.post("/api/karos",auth,async(req,res)=>{
 try{
   const {message,profile}=req.body||{};
   if(!message)return res.status(400).json({error:"Message required"});
   const userQ=await pool.query("SELECT profile_json FROM users WHERE id=$1",[req.user.sub]);
   const context=JSON.stringify({profile:profile||userQ.rows[0]?.profile_json||{},whiteRoom:true});
   if(!process.env.AI_API_KEY)return res.status(503).json({error:"AI backend not configured"});
   const r=await fetch(process.env.AI_API_URL||"https://api.openai.com/v1/chat/completions",{method:"POST",headers:{"Content-Type":"application/json","Authorization":`Bearer ${process.env.AI_API_KEY}`},body:JSON.stringify({model:process.env.AI_MODEL,messages:[{role:"system",content:KAROS_SYSTEM},{role:"system",content:`User context: ${context}`},{role:"user",content:message}],temperature:.55})});
   const d=await r.json();if(!r.ok)return res.status(502).json({error:"AI provider error"});
   res.json({reply:d.choices?.[0]?.message?.content||"KAROS returned no response."});
 }catch(e){res.status(500).json({error:"KAROS request failed"})}
});

app.listen(process.env.PORT||3000,()=>console.log(`AALC backend listening on ${process.env.PORT||3000}`));

# AALC — Third Build Architecture

## Included
- Mobile-first AALC frontend/PWA
- Personalized onboarding and starting-rank assessment
- Independent ranks for Mental, Knowledge, Skills, Spirituality and Physical Development
- E/D/C/B/A/S/X ladder
- S/X custom titles independently per domain
- Skill progression and evidence logging
- Physical performance scoring across context instead of exercise-specific ranks
- Martial-art multi-select
- Analytics dashboard and historical progress graph
- Achievements and milestones
- White Room unlock gate: S in Mental + S in Spirituality
- White Room curriculum
- Reading tracker and learning assessments
- KAROS chat interface
- Voice input architecture
- Browser speech output architecture
- Backend API source
- PostgreSQL schema
- JWT authentication
- User-to-user friendship and message APIs
- Cloud synchronization API structure
- KAROS memory table
- AI provider integration point

## Important deployment distinction
The frontend works as a local prototype using localStorage. The backend source is included but is not deployed by this ZIP. To make account recovery after uninstall and multi-device sync work, deploy the backend and PostgreSQL database, then point `frontend/app.js` CONFIG.API_BASE to the deployed API.

Do not put an AI provider secret in frontend code. Use backend environment variables.

## Rank logic
Ranks are independent by domain. XP thresholds:
E 0, D 100, C 250, B 500, A 900, S 1500, X 2500.

The starting assessment initializes XP from the user's stated evidence/experience selections. A production scoring engine should additionally validate evidence and use server-side anti-abuse rules.

## Custom titles
At S or X in a domain, the user can claim a custom title for that domain only.

## White Room
Unlock condition is intentionally dual-gated:
Mental >= 1500 AND Spirituality >= 1500.

## Fitness
Physical Development is optional. Health-oriented movement and appropriate nutrition are encouraged, but the system does not force structured fitness. Martial arts are optional and multiple styles can be selected.

## KAROS
The included backend has a server-side system prompt and provider endpoint. Set AI_API_KEY and AI_MODEL in backend/.env. The exact provider/model depends on the API service you choose.

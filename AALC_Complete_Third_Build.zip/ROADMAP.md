# Remaining production hardening

The source includes the requested architecture, but these are deployment/production tasks rather than missing UI features:

1. Deploy PostgreSQL.
2. Deploy Node backend.
3. Configure domain/HTTPS.
4. Configure AI provider and model.
5. Connect frontend API base.
6. Add WebSocket/push notifications for real-time chat if desired.
7. Add server-side rank/evidence validation and anti-abuse controls.
8. Add password reset/recovery that does not require Gmail/phone if the chosen product design supports secure recovery (for example, recovery codes).
9. Add encrypted backups and monitoring.
10. Package the PWA into an Android APK/AAB using a wrapper such as Capacitor after backend deployment.

No Play Store listing is required to distribute a signed APK directly, but Android installation and security policies still apply.
